-- SharedMedia_SaltyM: registers sounds and images with LibSharedMedia, so SaltyM+Helper,
-- BigWigs, WeakAuras and any other addon that uses LibSharedMedia can pick them.
--
-- To add your own: put the file in the "sounds" folder (.ogg or .mp3) or "Media" folder
-- (.tga or .blp, sizes that are a power of two such as 64x64 or 128x128), then add one line
-- below. The name in quotes is what you will see in the pickers. Restart the game after adding files.

local LSM = LibStub("LibSharedMedia-3.0")
local PATH = [[Interface\AddOns\SharedMedia_SaltyM\]]

-- sounds (short tones made for this addon)
LSM:Register("sound", "SaltyM Ping", PATH .. [[sounds\Ping.ogg]])
LSM:Register("sound", "SaltyM Chime", PATH .. [[sounds\Chime.ogg]])
LSM:Register("sound", "SaltyM Alert", PATH .. [[sounds\Alert.ogg]])
LSM:Register("sound", "SaltyM Drop", PATH .. [[sounds\Drop.ogg]])
LSM:Register("sound", "SaltyM Pulse", PATH .. [[sounds\Pulse.ogg]])
LSM:Register("sound", "SaltyM Fanfare", PATH .. [[sounds\Fanfare.ogg]])
LSM:Register("sound", "SaltyM Test (quiet)", PATH .. [[sounds\Test.ogg]]) -- soft beep used by the addon's check button

-- images
LSM:Register("background", "SaltyM Logo", PATH .. [[Media\logo.tga]])            -- 256x256
LSM:Register("background", "SaltyM Logo (64)", PATH .. [[Media\logo64.tga]])      -- small version for icons

-- your own files go here, for example:
-- LSM:Register("sound", "My Meow", PATH .. [[sounds\meow.ogg]])
-- LSM:Register("background", "My Icon", PATH .. [[Media\myicon.tga]])
